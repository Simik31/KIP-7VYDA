-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2020 at 10:15 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vydap_projekt`
--

-- --------------------------------------------------------

--
-- Table structure for table `mistnosti`
--

CREATE TABLE `mistnosti` (
  `zkratka_mistnosti` varchar(5) COLLATE utf8_czech_ci NOT NULL,
  `popis` varchar(30) COLLATE utf8_czech_ci NOT NULL,
  `kapacita` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `mistnosti`
--

INSERT INTO `mistnosti` (`zkratka_mistnosti`, `popis`, `kapacita`) VALUES
('A-210', 'Učebna', 66),
('A-211', 'Učebna', 66),
('A-302', 'Učebna', 66),
('C-103', 'Učebna', 66);

-- --------------------------------------------------------

--
-- Table structure for table `pedagogove`
--

CREATE TABLE `pedagogove` (
  `kod_pedagoga` varchar(10) COLLATE utf8_czech_ci NOT NULL,
  `jmeno` varchar(30) COLLATE utf8_czech_ci NOT NULL,
  `prijmeni` varchar(30) COLLATE utf8_czech_ci NOT NULL,
  `tituly_pred_jmenem` varchar(20) COLLATE utf8_czech_ci NOT NULL,
  `tituly_za_jmenem` varchar(20) COLLATE utf8_czech_ci NOT NULL,
  `heslo` varchar(64) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `pedagogove`
--

INSERT INTO `pedagogove` (`kod_pedagoga`, `jmeno`, `prijmeni`, `tituly_pred_jmenem`, `tituly_za_jmenem`, `heslo`) VALUES
('1', 'Bogdan', 'Walek', 'RNDr.', 'Ph.D.', '$2y$10$mH3tqG0SxYdmBaqr9jo2vebc6HSNxJ8T9JhvHwmt0UYPDWX4/QrnG'),
('2', 'Rostislav', 'Fojtík', 'Mgr.', 'Ph.D.', '$2y$10$b4gyWoapGYLQnEVPSDD2M.AlGYo38Drq/S4PDEwlz60MzVaXSddEK'),
('3', 'Marek', 'Vajgl', 'RNDr.', 'Ph.D.', '$2y$10$1mG4AaofvLHRKvp9iPkB4uvOQ0AOHOFSU29GsPOfqTXVNIDqmIcJG'),
('4', 'Pavel', 'Smolka', 'Ing.', 'Ph.D.', '$2y$10$yy4deg46MeT6b3szgfxameSwYSQ3nCQvOjwn.9ATt2zwxFpu/skGG'),
('5', 'František', 'Huňka', 'Doc. Ing.', 'CSc.', '$2y$10$T6oaLdk9bF6PwbDBbcfZYuWef0fMLTIAaNk6VtMIojazCwS9nASlu');

-- --------------------------------------------------------

--
-- Table structure for table `pedagogove_predmety`
--

CREATE TABLE `pedagogove_predmety` (
  `kod_pedagoga` varchar(10) COLLATE utf8_czech_ci NOT NULL,
  `zkratka_predmetu` varchar(5) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `pedagogove_predmety`
--

INSERT INTO `pedagogove_predmety` (`kod_pedagoga`, `zkratka_predmetu`) VALUES
('1', '7VYDA'),
('2', '7PRCC'),
('2', '7VYDA'),
('3', '7PRCS'),
('4', '7POLP'),
('5', '7OPR1');

-- --------------------------------------------------------

--
-- Table structure for table `predmety`
--

CREATE TABLE `predmety` (
  `zkratka_predmetu` varchar(5) COLLATE utf8_czech_ci NOT NULL,
  `nazev` varchar(50) COLLATE utf8_czech_ci NOT NULL,
  `pocet_kreditu` smallint(6) NOT NULL,
  `pocet_hodin_prednasek` smallint(6) NOT NULL,
  `pocet_hodin_cviceni` smallint(6) NOT NULL,
  `ukonceni` varchar(2) COLLATE utf8_czech_ci NOT NULL,
  `anotace` text COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `predmety`
--

INSERT INTO `predmety` (`zkratka_predmetu`, `nazev`, `pocet_kreditu`, `pocet_hodin_prednasek`, `pocet_hodin_cviceni`, `ukonceni`, `anotace`) VALUES
('7OPR1', 'Objektově orientované programování 1', 5, 52, 38, 'Zk', 'Cílem kurzu je seznámit studenty se základními koncepty objektově orientovaného programování a jejich praktickému využití při tvorbě programů a aplikací. Dalším cílem kurzu je objasnit a vštípit studentům objektově orientovaný přístup k návrhu počítačových aplikací.'),
('7POLP', 'Prvky elektronických počítačů', 4, 26, 30, 'Zk', 'Student porozumí následujícím oblastem: Základní prvky počítačů, číslicovým obvodům, prvkům a obvodům polovodičových pamětí, vnějším pamětem, obvodům klávesnic a zobrazovacích systémů, elektrickým parametrům spojů v číslicových zařízeních, napájecím zdrojům, A/D a D/A převodníkům, problematice měření času a kmitočtu. Student pochopí princip činnosti paralelního a sériového rozhraní, konstrukci jednočipových řadičů a mikropočítačů.\r\n'),
('7PRCC', 'Programování v C/C++', 4, 52, 30, 'Za', 'Cílem předmětu je seznámit studenty se základy programovacích jazyků C a C++, jejich hlavními rysy, výhodami a nevýhodami jazyků a způsobem zpracování programů. Předmět objasňuje využití pointerů, preprocesoru, funkcí a datových typů. Studenti se seznámí s praktickým využitím objektově orientovaného programování v jazyku C++ a použitím standardních knihoven šablon.'),
('7PRCS', 'Programování v C#', 4, 52, 39, 'Za', 'Cílem předmětu je seznámit studenty s platformou .NET, vysvětlit její principy a způsoby tvorby aplikací pro .NET v jazyce C# v IDE Microsoft Visual Studio.'),
('7VYDA', 'Webové a databázové aplikace v PHP', 4, 39, 20, 'Za', 'Úvod předmětu je věnován seznámení s protokolem HTTP a formuláři v HTML. Dále už je předmět zaměřen na tvorbu webových aplikací v jazyce PHP s propojením na databázi MySQL. Student by měl být po absolvování předmětu schopen samostatně vytvářet webové aplikace v PHP. V závěru semestru se studenti seznámí s PHP frameworky.\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `studenti`
--

CREATE TABLE `studenti` (
  `kod_studenta` varchar(10) COLLATE utf8_czech_ci NOT NULL,
  `jmeno` varchar(30) COLLATE utf8_czech_ci NOT NULL,
  `prijmeni` varchar(30) COLLATE utf8_czech_ci NOT NULL,
  `heslo` varchar(64) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `studenti`
--

INSERT INTO `studenti` (`kod_studenta`, `jmeno`, `prijmeni`, `heslo`) VALUES
('1', 'Martin', 'Šimara', '$2y$10$J4bvTU21.vqIY/1K7rBkZunqwwLLbiu9r05nW8eVIfIx.1vumd7ee'),
('2', 'Milan', 'Fucek', '$2y$10$lOgkRSq2RVfCvyurO2QSw./ulVDgM.RgaeVmzgU5Ic8aQSjsKO/Le'),
('3', 'Michal', 'Novák', '$2y$10$le.3/0qgdFkw83wJrV4J5uzFGPluWp5KTim7v/oTEeK7NlqEAW/ES'),
('4', 'Ondřej', 'Michna', '$2y$10$huJZfyW/74QAWU1q10PeiuXbxsdFJtklkvYyZ2TI8p5bLF/CPL2zC'),
('5', 'Martin', 'Zapletal', '$2y$10$XaQmvLeYF3CQ.rA9vT5tieDaAKuHGCnN1NaMFAirjuJDJrOeXSt4K');

-- --------------------------------------------------------

--
-- Table structure for table `studenti_predmety`
--

CREATE TABLE `studenti_predmety` (
  `kod_studenta` varchar(10) COLLATE utf8_czech_ci NOT NULL,
  `zkratka_predmetu` varchar(5) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `studenti_predmety`
--

INSERT INTO `studenti_predmety` (`kod_studenta`, `zkratka_predmetu`) VALUES
('1', '7OPR1'),
('1', '7POLP'),
('1', '7PRCC'),
('1', '7PRCS'),
('1', '7VYDA'),
('2', '7PRCS'),
('2', '7VYDA'),
('3', '7OPR1'),
('3', '7PRCC'),
('3', '7VYDA'),
('4', '7OPR1'),
('4', '7PRCC'),
('4', '7PRCS'),
('5', '7OPR1'),
('5', '7POLP');

-- --------------------------------------------------------

--
-- Table structure for table `vypsane_terminy`
--

CREATE TABLE `vypsane_terminy` (
  `id_terminu` int(11) NOT NULL,
  `zkratka_mistnosti` varchar(5) COLLATE utf8_czech_ci NOT NULL,
  `kod_pedagoga` varchar(10) COLLATE utf8_czech_ci NOT NULL,
  `zkratka_predmetu` varchar(5) COLLATE utf8_czech_ci NOT NULL,
  `datum_cas` datetime NOT NULL,
  `max_pocet_prihlasenych` smallint(6) NOT NULL,
  `poznamka` varchar(200) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `vypsane_terminy`
--

INSERT INTO `vypsane_terminy` (`id_terminu`, `zkratka_mistnosti`, `kod_pedagoga`, `zkratka_predmetu`, `datum_cas`, `max_pocet_prihlasenych`, `poznamka`) VALUES
(1, 'A-210', '1', '7VYDA', '2020-09-26 20:00:00', 16, ''),
(2, 'A-211', '2', '7PRCC', '2020-09-27 20:00:00', 22, ''),
(3, 'A-302', '3', '7PRCC', '2020-09-28 20:00:00', 16, ''),
(4, 'C-103', '1', '7VYDA', '2020-10-11 12:49:00', 66, ''),
(5, 'A-210', '3', '7PRCS', '2020-10-30 02:11:00', 16, ''),
(6, 'A-210', '4', '7POLP', '2020-11-14 02:11:00', 16, ''),
(7, 'A-210', '5', '7OPR1', '2020-12-24 02:11:00', 16, ''),
(8, 'A-210', '1', '7VYDA', '2020-10-11 22:43:00', 16, ''),
(9, 'A-210', '1', '7VYDA', '2020-11-06 22:43:00', 16, ''),
(10, 'A-210', '1', '7VYDA', '2020-10-09 22:43:00', 16, ''),
(11, 'A-210', '1', '7VYDA', '2020-10-08 22:43:00', 16, ''),
(13, 'A-210', '3', '7PRCS', '2020-10-10 22:45:00', 16, ''),
(14, 'A-210', '3', '7PRCS', '2020-11-07 22:45:00', 16, ''),
(15, 'A-210', '3', '7PRCS', '2020-11-20 22:45:00', 16, ''),
(16, 'A-210', '1', '7VYDA', '2020-10-30 10:42:00', 16, ''),
(17, 'C-103', '1', '7VYDA', '2021-03-19 12:00:00', 66, 'můžu ručně zadat špatný rok (to je jen pro přípat že by byl učitel morous)'),
(18, 'C-103', '2', '7VYDA', '2020-10-29 03:52:00', 66, 'F');

-- --------------------------------------------------------

--
-- Table structure for table `vysledky`
--

CREATE TABLE `vysledky` (
  `id_vysledku` smallint(6) NOT NULL,
  `popis` varchar(20) COLLATE utf8_czech_ci NOT NULL,
  `typ` varchar(2) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `vysledky`
--

INSERT INTO `vysledky` (`id_vysledku`, `popis`, `typ`) VALUES
(1, '', 'Zk'),
(3, '', 'Za'),
(4, '', 'Za'),
(5, '', 'Za'),
(6, '', 'Zk');

-- --------------------------------------------------------

--
-- Table structure for table `zapsane_terminy`
--

CREATE TABLE `zapsane_terminy` (
  `id_terminu` int(11) NOT NULL,
  `kod_studenta` varchar(10) COLLATE utf8_czech_ci NOT NULL,
  `id_vysledku` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Dumping data for table `zapsane_terminy`
--

INSERT INTO `zapsane_terminy` (`id_terminu`, `kod_studenta`, `id_vysledku`) VALUES
(1, '1', 1),
(1, '2', 3),
(4, '1', 4),
(5, '1', 5),
(6, '1', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mistnosti`
--
ALTER TABLE `mistnosti`
  ADD PRIMARY KEY (`zkratka_mistnosti`);

--
-- Indexes for table `pedagogove`
--
ALTER TABLE `pedagogove`
  ADD PRIMARY KEY (`kod_pedagoga`);

--
-- Indexes for table `pedagogove_predmety`
--
ALTER TABLE `pedagogove_predmety`
  ADD PRIMARY KEY (`kod_pedagoga`,`zkratka_predmetu`),
  ADD KEY `zkratka_predmetu` (`zkratka_predmetu`);

--
-- Indexes for table `predmety`
--
ALTER TABLE `predmety`
  ADD PRIMARY KEY (`zkratka_predmetu`);

--
-- Indexes for table `studenti`
--
ALTER TABLE `studenti`
  ADD PRIMARY KEY (`kod_studenta`);

--
-- Indexes for table `studenti_predmety`
--
ALTER TABLE `studenti_predmety`
  ADD PRIMARY KEY (`kod_studenta`,`zkratka_predmetu`),
  ADD KEY `zkratka_predmetu` (`zkratka_predmetu`);

--
-- Indexes for table `vypsane_terminy`
--
ALTER TABLE `vypsane_terminy`
  ADD PRIMARY KEY (`id_terminu`),
  ADD KEY `id_terminu` (`id_terminu`,`zkratka_mistnosti`,`kod_pedagoga`,`zkratka_predmetu`,`datum_cas`,`max_pocet_prihlasenych`,`poznamka`),
  ADD KEY `zkratka_mistnosti` (`zkratka_mistnosti`),
  ADD KEY `zkratka_predmetu` (`zkratka_predmetu`),
  ADD KEY `kod_pedagoga` (`kod_pedagoga`);

--
-- Indexes for table `vysledky`
--
ALTER TABLE `vysledky`
  ADD PRIMARY KEY (`id_vysledku`);

--
-- Indexes for table `zapsane_terminy`
--
ALTER TABLE `zapsane_terminy`
  ADD PRIMARY KEY (`id_terminu`,`kod_studenta`),
  ADD KEY `kod_studenta` (`kod_studenta`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `vypsane_terminy`
--
ALTER TABLE `vypsane_terminy`
  MODIFY `id_terminu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `pedagogove_predmety`
--
ALTER TABLE `pedagogove_predmety`
  ADD CONSTRAINT `pedagogove_predmety_ibfk_1` FOREIGN KEY (`kod_pedagoga`) REFERENCES `pedagogove` (`kod_pedagoga`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pedagogove_predmety_ibfk_2` FOREIGN KEY (`zkratka_predmetu`) REFERENCES `predmety` (`zkratka_predmetu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `studenti_predmety`
--
ALTER TABLE `studenti_predmety`
  ADD CONSTRAINT `studenti_predmety_ibfk_1` FOREIGN KEY (`zkratka_predmetu`) REFERENCES `predmety` (`zkratka_predmetu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `studenti_predmety_ibfk_2` FOREIGN KEY (`kod_studenta`) REFERENCES `studenti` (`kod_studenta`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `vypsane_terminy`
--
ALTER TABLE `vypsane_terminy`
  ADD CONSTRAINT `vypsane_terminy_ibfk_1` FOREIGN KEY (`zkratka_predmetu`) REFERENCES `predmety` (`zkratka_predmetu`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vypsane_terminy_ibfk_2` FOREIGN KEY (`kod_pedagoga`) REFERENCES `pedagogove` (`kod_pedagoga`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vypsane_terminy_ibfk_3` FOREIGN KEY (`zkratka_mistnosti`) REFERENCES `mistnosti` (`zkratka_mistnosti`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `zapsane_terminy`
--
ALTER TABLE `zapsane_terminy`
  ADD CONSTRAINT `zapsane_terminy_ibfk_1` FOREIGN KEY (`kod_studenta`) REFERENCES `studenti` (`kod_studenta`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `zapsane_terminy_ibfk_2` FOREIGN KEY (`id_terminu`) REFERENCES `vypsane_terminy` (`id_terminu`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
